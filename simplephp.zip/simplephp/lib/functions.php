<?php
require_once __DIR__ . "/../vendor/autoload.php"; 

// Function to decode JSON response
function getJSON($jsonResponse){
    $data = json_decode($jsonResponse);

    // Check if the JSON decoding was successful
    if ($data !== null) {
        $success = $data->success; // true
        $message = $data->message; // "Update successful"

        // Determine the return value based on success status
        if ($success) {
            $val = true;
        } else {
            $val = false;
        }
    } else {
        // JSON parsing failed
        $val = "error";
    }
    return $val;
}

// Function to get the base URL from .env
function base_url(){
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . "/..");
    $dotenv->load();
    $base = $_ENV["BASE_URL"];
    return $base;
}

// Function to display checkbox value as readable text
function ShowCheckBoxValue($val){
    return $val === 0 ? "Tidak" : "Ya";
}

// Function to get the theme from .env
function setTheme(){
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . "/..");
    $dotenv->load();
    $theme = $_ENV["THEME"];
    return $theme;
}

// Function to include header for main theme
function getHeader($theme_name){
    include("../themes/" . $theme_name . "/header.php"); 
    include("../themes/" . $theme_name . "/leftmenu.php"); 
    include("../themes/" . $theme_name . "/topnav.php");
    include("../themes/" . $theme_name . "/upper_block.php");
}

// Function to include footer for main theme
function getFooter($theme_name, $extra){
    include("../themes/" . $theme_name . "/lower_block.php"); 
    echo $extra;
    include("../themes/" . $theme_name . "/footer.php"); 
    
    echo '</body>
    </html>';
}

// Function to include header for login theme
function getHeaderLogin($theme_name){
    include("themes/" . $theme_name . "/headerlogin.php"); 
    include("themes/" . $theme_name . "/leftmenulogin.php"); 
    include("themes/" . $theme_name . "/topnav.php");
    include("themes/" . $theme_name . "/upper_block.php");
}

// Function to include footer for login theme
function getFooterLogin($theme_name, $extra){
    include("themes/" . $theme_name . "/lower_block.php"); 
    echo $extra;
    include("themes/" . $theme_name . "/footerlogin.php"); 
    
    echo '</body>
    </html>';
}

// Function to get the current filename
function getFilename(){
    $host = $_SERVER["HTTP_HOST"];
    $uri = $_SERVER["REQUEST_URI"];
    $url = "http://" . $host . $uri;
    $parsed_url = parse_url($url);

    // Get the path from the parsed URL
    $path = $parsed_url["path"];

    // Use pathinfo to extract the filename
    $file_info = pathinfo($path);

    // Return the filename
    return $file_info["basename"];
}
?>
